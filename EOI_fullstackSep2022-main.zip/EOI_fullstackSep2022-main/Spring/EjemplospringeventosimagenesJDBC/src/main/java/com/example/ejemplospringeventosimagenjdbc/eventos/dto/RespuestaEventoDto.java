package com.example.ejemplospringeventosimagenjdbc.eventos.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data @AllArgsConstructor
public class RespuestaEventoDto {
    EventoConUsuariosDto evento;
}
