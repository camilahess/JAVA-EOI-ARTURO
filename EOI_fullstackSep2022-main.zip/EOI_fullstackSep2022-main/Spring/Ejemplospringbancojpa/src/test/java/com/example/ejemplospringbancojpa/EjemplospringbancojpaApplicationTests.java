package com.example.ejemplospringbancojpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjemplospringbancojpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
