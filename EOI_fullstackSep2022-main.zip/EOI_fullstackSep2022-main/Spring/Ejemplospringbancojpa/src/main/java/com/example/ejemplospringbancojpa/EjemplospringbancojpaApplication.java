package com.example.ejemplospringbancojpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EjemplospringbancojpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(EjemplospringbancojpaApplication.class, args);
	}

}
