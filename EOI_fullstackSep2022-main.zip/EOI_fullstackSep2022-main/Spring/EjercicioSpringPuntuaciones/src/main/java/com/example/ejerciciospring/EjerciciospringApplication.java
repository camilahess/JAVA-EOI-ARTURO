package com.example.ejerciciospring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EjerciciospringApplication {

	public static void main(String[] args) {
		SpringApplication.run(EjerciciospringApplication.class, args);
	}

}
