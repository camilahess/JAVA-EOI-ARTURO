package com.example.ejerciciospring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjerciciospringApplicationTests {

	@Test
	void contextLoads() {
	}

}
