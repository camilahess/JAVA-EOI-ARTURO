package com.example.ejemplospringeventos.eventos.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data @NoArgsConstructor
public class AsistirEventoDto {
    private int usuario;
}
