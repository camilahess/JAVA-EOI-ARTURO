package com.example.ejemplospringeventos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EjemplospringeventosApplication {

	public static void main(String[] args) {
		SpringApplication.run(EjemplospringeventosApplication.class, args);
	}

}
