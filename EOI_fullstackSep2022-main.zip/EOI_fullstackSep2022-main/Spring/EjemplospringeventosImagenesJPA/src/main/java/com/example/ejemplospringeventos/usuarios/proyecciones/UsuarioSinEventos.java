package com.example.ejemplospringeventos.usuarios.proyecciones;

public interface UsuarioSinEventos {
    int getId();
    String getNombre();
    String getCorreo();
}
