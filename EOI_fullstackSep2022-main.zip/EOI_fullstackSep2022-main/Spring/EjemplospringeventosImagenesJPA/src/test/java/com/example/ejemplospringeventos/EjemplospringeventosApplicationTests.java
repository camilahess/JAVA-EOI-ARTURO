package com.example.ejemplospringeventos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjemplospringeventosApplicationTests {

	@Test
	void contextLoads() {
	}

}
