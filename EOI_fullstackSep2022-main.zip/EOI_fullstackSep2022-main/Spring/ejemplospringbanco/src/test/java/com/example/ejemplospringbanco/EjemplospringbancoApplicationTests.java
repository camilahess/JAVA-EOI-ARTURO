package com.example.ejemplospringbanco;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjemplospringbancoApplicationTests {

	@Test
	void contextLoads() {
	}

}
