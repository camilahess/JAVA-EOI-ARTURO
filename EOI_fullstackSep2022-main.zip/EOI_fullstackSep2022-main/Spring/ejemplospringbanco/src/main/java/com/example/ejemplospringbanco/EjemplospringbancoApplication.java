package com.example.ejemplospringbanco;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EjemplospringbancoApplication {

	public static void main(String[] args) {
		SpringApplication.run(EjemplospringbancoApplication.class, args);
	}

}
