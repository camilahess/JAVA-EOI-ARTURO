package com.example.ejerciciospringequipos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjerciciospringequiposApplicationTests {

	@Test
	void contextLoads() {
	}

}
