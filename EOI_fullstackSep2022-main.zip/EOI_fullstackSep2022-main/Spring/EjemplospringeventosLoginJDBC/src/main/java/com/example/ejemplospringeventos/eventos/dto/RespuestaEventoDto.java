package com.example.ejemplospringeventos.eventos.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data @AllArgsConstructor
public class RespuestaEventoDto {
    EventoConUsuariosDto evento;
}
