public interface IFigura {
    public double getArea();
    public double getPerimetro();
}
