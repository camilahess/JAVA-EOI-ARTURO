public interface IHablador {
    public void hablar();
}
